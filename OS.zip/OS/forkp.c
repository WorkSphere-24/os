#include <sys/types.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/wait.h>

int partition(int arr[], int low, int high)
{
    int pivot = arr[high];
    int i = (low - 1);
    for (int j = low; j < high; j++)
    {
        if (arr[j] < pivot)
        {
            i++;
            int temp = arr[i];
            arr[i] = arr[j];
            arr[j] = temp;
        }
    }
    int temp = arr[i + 1];
    arr[i + 1] = arr[high];
    arr[high] = temp;
    return (i + 1);
}

void quick_sort(int arr[], int low, int high)
{
    if (low < high)
    {
        int pi = partition(arr, low, high);
        quick_sort(arr, low, pi - 1);
        quick_sort(arr, pi + 1, high);
    }
}

void print_array(int arr[], int n)
{
    printf("Sorted array is ");
    for (int i = 0; i < n; i++)
    {
        printf("%d ", arr[i]);
    }
    printf("\n");
}

void execute_child_process(int choice)
{
    sleep(10);
    system("ps -ax | grep a.out");
    printf("This is the child\nProcess ID: %d, Parent ID: %d\n", (int)getpid(), (int)getppid());

    if (choice == 2)
    {
        // Orphan child continues to run
        for (int i = 0; i < 5; i++)
        {
            printf("Child process running... (PID: %d)\n", (int)getpid());
            sleep(1);
        }
    }
}

void execute_parent_process(int choice, int arr[], int k)
{
    if (choice == 1) // Sort in parent
    {
        printf("Sorting array in parent process...\n");
        quick_sort(arr, 0, k - 1);
        print_array(arr, k);
    }
    else if (choice == 2) // Orphan process
    {
        for (int i = 0; i < 3; i++)
        {
            printf("Parent process running... (PID: %d)\n", (int)getpid());
            sleep(1);
        }
    }
    else if (choice == 3) // Zombie process
    {
        sleep(10); // Give time for child to become a zombie
    }
}

int main()
{
    int k, choice;
    int arr[10];

    printf("Enter number of integers to be sorted: ");
    scanf("%d", &k);
    printf("Enter the integers: ");
    for (int i = 0; i < k; i++)
    {
        scanf("%d", &arr[i]);
    }

    printf("1. Sort array in parent process\n2. Orphan process\n3. Zombie process\nEnter choice: ");
    scanf("%d", &choice);

    printf("Main process ID: %d\n", (int)getpid());
    pid_t pid = fork();

    if (pid < 0)
    {
        perror("Fork failed");
        exit(1);
    }
    else if (pid == 0) // Child process
    {
        execute_child_process(choice);
        printf("Exiting child process\n");
    }
    else // Parent process
    {
        if (choice != 3) // Don't wait in case of zombie creation
        {
            wait(NULL);
        }
        execute_parent_process(choice, arr, k);
    }

    return 0;
}

