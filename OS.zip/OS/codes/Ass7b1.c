#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <unistd.h>

#define SHM_SIZE 1024 // Size of shared memory segment

int main() {
    // Generate a unique key
    key_t key = ftok("server.c", 65);
    
    // Create a shared memory segment
    int shmid = shmget(key, SHM_SIZE, 0666 | IPC_CREAT);
    if (shmid == -1) {
        perror("shmget failed");
        exit(1);
    }

    // Attach to the shared memory segment
    char *str = (char *)shmat(shmid, NULL, 0);
    if (str == (char *)(-1)) {
        perror("shmat failed");
        exit(1);
    }

    // Wait for the client to write a message
    printf("Server: Waiting for client message...\n");
    while (1) {
        if (strlen(str) > 0) { // Check if there's a message
            printf("Server: Received message: %s\n", str);
            break;
        }
        sleep(1);
    }

    // Detach from and clean up the shared memory segment
    shmdt(str);
    shmctl(shmid, IPC_RMID, NULL);

    return 0;
}

