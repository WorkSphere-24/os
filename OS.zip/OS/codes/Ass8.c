#include <stdio.h>
#include <stdlib.h>
#define MAX_TRACKS 100
#define MAX_TRACK_LIMIT 199 // Disk has tracks from 0 to 199
void sstf(int tracks[], int n, int head);
void scan(int tracks[], int n, int head, int direction);
void clook(int tracks[], int n, int head);
void sort_tracks(int tracks[], int n);
int main()
{
    int tracks[MAX_TRACKS];
    int n, head, choice, direction;
    printf("Enter the number of tracks: ");
    scanf("%d", &n);
    // Validate number of tracks
    if (n <= 0 || n > MAX_TRACKS)
    {
        printf("Invalid number of tracks. Must be between 1 and %d.\n", MAX_TRACKS);
        return -1;
    }
    printf("Enter the track numbers (0 to %d):\n", MAX_TRACK_LIMIT);
    for (int i = 0; i < n; i++)
    {
        scanf("%d", &tracks[i]);
        // Validate each track number to be within the valid range
        if (tracks[i] < 0 || tracks[i] > MAX_TRACK_LIMIT)
        {
            printf("Track number must be between 0 and %d.\n", MAX_TRACK_LIMIT);
            return -1;
        }
    }
    printf("Enter the initial head position (0 to %d): ", MAX_TRACK_LIMIT);
    scanf("%d", &head);
    if (head < 0 || head > MAX_TRACK_LIMIT)
    {
        printf("Invalid head position. Must be between 0 and %d.\n", MAX_TRACK_LIMIT);
        return -1;
    }

    while (1)
    {
        printf("\nChoose the disk scheduling algorithm:\n");
        printf("1. SSTF\n");
        printf("2. SCAN\n");
        printf("3. C-LOOK\n");
        printf("4. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);
        switch (choice)
        {
        case 1:
            sstf(tracks, n, head);
            break;
        case 2:
            printf("Enter direction (0 for left, 1 for right): ");
            scanf("%d", &direction);
            if (direction != 0 && direction != 1)
                printf("Invalid direction.\n");
            else
                scan(tracks, n, head, direction);
            break;
        case 3:
            clook(tracks, n, head);
            break;
        case 4:
            printf("Exiting...\n");
            exit(0); // Exit the program
        default:
            printf("Invalid choice. Please enter a valid option.\n");
        }
    }
    return 0;
}
void sstf(int tracks[], int n, int head)
{
    int visited[MAX_TRACKS] = {0};
    int total_seek_time = 0;
    int current_position = head;
    int count = 0;
    printf("\nRequest Order (Track | Seek Time):\n");
    printf("----------------------------------\n");

    while (count < n)
    {
        int min_distance = 1e9, index = -1;
        for (int i = 0; i < n; i++)
        {
            if (!visited[i] && abs(tracks[i] - current_position) < min_distance)
            {
                min_distance = abs(tracks[i] - current_position);
                index = i;
            }
        }
        visited[index] = 1;
        total_seek_time += min_distance;
        printf("%8d | %10d\n", tracks[index], min_distance);
        current_position = tracks[index];
        count++;
    }
    printf("\nTotal Seek Time: %d\n", total_seek_time);
    printf("Average Seek Time: %.2f\n", (float)total_seek_time / n);
}
void scan(int tracks[], int n, int head, int direction)
{
    int total_seek_time = 0;
    int current_position = head;
    // Sort the tracks
    sort_tracks(tracks, n);
    printf("\nRequest Order (Track | Seek Time):\n");
    printf("----------------------------------\n");
    if (direction == 1)
    { // Right
        for (int i = 0; i < n; i++)
        {
            if (tracks[i] >= current_position)
            {
                int seek_time = abs(current_position - tracks[i]);
                printf("%8d | %10d\n", tracks[i], seek_time);
                total_seek_time += seek_time;
                current_position = tracks[i];
            }
        }
        total_seek_time += abs(current_position - MAX_TRACK_LIMIT); // Move to the end

        current_position = MAX_TRACK_LIMIT; // Now at the end
    
        for (int i = n - 1; i >= 0; i--)
        {
            if (tracks[i] < head)
            {
                int seek_time = abs(current_position - tracks[i]);
                printf("%8d | %10d\n", tracks[i], seek_time);
                total_seek_time += seek_time;
                current_position = tracks[i];
            }
        }
    }
    else
    { // Left
        for (int i = n - 1; i >= 0; i--)
        {
            if (tracks[i] <= current_position)
            {
                int seek_time = abs(current_position - tracks[i]);
                printf("%8d | %10d\n", tracks[i], seek_time);
                total_seek_time += seek_time;
                current_position = tracks[i];
            }
        }
        total_seek_time += abs(current_position - 0); // Move to the start
        current_position = 0;                         // Now at the start
        for (int i = 0; i < n; i++)
        {
            if (tracks[i] > head)
            {
                int seek_time = abs(current_position - tracks[i]);
                printf("%8d | %10d\n", tracks[i], seek_time);
                total_seek_time += seek_time;
                current_position = tracks[i];
            }
        }
    }
    printf("\nTotal Seek Time: %d\n", total_seek_time);
    printf("Average Seek Time: %.2f\n", (float)total_seek_time / n);
}
void clook(int tracks[], int n, int head)
{
    int total_seek_time = 0;
    int current_position = head;
    // Sort the tracks
    sort_tracks(tracks, n);
    printf("\nRequest Order (Track | Seek Time):\n");
    printf("----------------------------------\n");

    // First loop: service requests greater than or equal to the head
    int i = 0;
    while (i < n && tracks[i] < current_position)
    {
        i++;
    }

    for (; i < n; i++)
    {
        int seek_time = abs(current_position - tracks[i]);
        printf("%8d | %10d\n", tracks[i], seek_time);
        total_seek_time += seek_time;
        current_position = tracks[i];
    }

    // Wrap around to the beginning and service remaining requests
    for (int j = 0; j < n && tracks[j] < head; j++)
    {
        int seek_time = abs(current_position - tracks[j]);
        printf("%8d | %10d\n", tracks[j], seek_time);
        total_seek_time += seek_time;
        current_position = tracks[j];
    } 

    printf("\nTotal Seek Time: %d\n", total_seek_time);
    printf("Average Seek Time: %.2f\n", (float)total_seek_time / n);
}
// Utility function to sort the tracks array
void sort_tracks(int tracks[], int n)
{
    for (int i = 0; i < n - 1; i++)
    {
        for (int j = 0; j < n - i - 1; j++)
        {
            if (tracks[j] > tracks[j + 1])
            {
                int temp = tracks[j];
                tracks[j] = tracks[j + 1];
                tracks[j + 1] = temp;
            }
        }
    }
}