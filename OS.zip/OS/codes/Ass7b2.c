#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ipc.h>
#include <sys/shm.h>

#define SHM_SIZE 1024 // Size of shared memory segment

int main() {
    // Generate the same key as in the server
    key_t key = ftok("server.c", 65);

    // Get the shared memory segment created by the server
    int shmid = shmget(key, SHM_SIZE, 0666);
    if (shmid == -1) {
        perror("shmget failed");
        exit(1);
    }

    // Attach to the shared memory segment
    char *str = (char *)shmat(shmid, NULL, 0);
    if (str == (char *)(-1)) {
        perror("shmat failed");
        exit(1);
    }

    // Write a message to shared memory
    printf("Client: Enter a message: ");
    fgets(str, SHM_SIZE, stdin);

    // Remove the newline character from the end if present
    str[strcspn(str, "\n")] = '\0';

    // Detach from the shared memory segment
    shmdt(str);

    return 0;
}

