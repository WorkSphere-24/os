#include <stdio.h>
#include <stdbool.h>
#define MAX_PROCESSES 10
#define MAX_RESOURCES 10
int allocation[MAX_PROCESSES][MAX_RESOURCES];
int maximum[MAX_PROCESSES][MAX_RESOURCES];
int need[MAX_PROCESSES][MAX_RESOURCES];
int available[MAX_RESOURCES];
int numProcesses, numResources;
void calculateNeed()
{
    for (int i = 0; i < numProcesses; i++)
    {
        for (int j = 0; j < numResources; j++)
        {
            need[i][j] = maximum[i][j] - allocation[i][j];
        }
    }
}
bool isSafe(int safeSequence[])
{
    int work[MAX_RESOURCES];
    bool finish[MAX_PROCESSES] = {false};
    for (int i = 0; i < numResources; i++)
    {
        work[i] = available[i];
    }
    int count = 0;
    while (count < numProcesses)
    {
        bool found = false;
        for (int p = 0; p < numProcesses; p++)
        {
            if (!finish[p])
            {
                int j;
                for (j = 0; j < numResources; j++)
                {
                    if (need[p][j] > work[j])
                    {
                        break;
                    }
                }
                if (j == numResources)
                {
                    for (int k = 0; k < numResources; k++)
                    {
                        work[k] += allocation[p][k];
                    }
                    safeSequence[count++] = p;
                    finish[p] = true;
                    found = true;
                }
            }
        }
        if (!found)
        {
            return false; // System is not in a safe state
        }
    }
    return true; // System is in a safe state
}
void requestResources(int processID, int request[])
{
    for (int j = 0; j < numResources; j++)
    {
        if (request[j] > need[processID][j])
        {
            printf("Error: Process has exceeded its maximum claim.\n");
            return;
        }
        if (request[j] > available[j])
        {
            printf("Process is requesting resources that are not available.\n");
            return;
        }
    }
    // Pretend to allocate resources
    for (int j = 0; j < numResources; j++)
    {
        available[j] -= request[j];
        allocation[processID][j] += request[j];
        need[processID][j] -= request[j];
    }
    int safeSequence[MAX_PROCESSES];
    if (isSafe(safeSequence))
    {
        printf("Resources allocated successfully.\n");
        printf("Safe Sequence: ");
        for (int i = 0; i < numProcesses; i++)
        {
            printf("%d ", safeSequence[i]);
        }
        printf("\n");
    }
    else
    {
        // Rollback the changes
        for (int j = 0; j < numResources; j++)
        {
            available[j] += request[j];
            allocation[processID][j] -= request[j];
            need[processID][j] += request[j];
        }
        printf("Resources allocation denied, system not in a safe state.\n");
    }
}
void displayMenu()
{
    printf("\nMenu:\n");
    printf("1) Calculate Need\n");
    printf("2) Check For Safety\n");
    printf("3) Accept Request From User\n");
    printf("4) Exit\n");
    printf("Choose an option: ");
}
int main()
{
    printf("Enter the number of processes: ");
    scanf("%d", &numProcesses);
    printf("Enter the number of resource types: ");
    scanf("%d", &numResources);
    // Available resources
    printf("Enter available resources:\n");
    for (int i = 0; i < numResources; i++)
    {
        printf("Resource %d: ", i);
        scanf("%d", &available[i]);
    }
    // Maximum resources for each process
    printf("Enter maximum resources for each process:\n");
    for (int i = 0; i < numProcesses; i++)
    {
        printf("Process %d: ", i);
        for (int j = 0; j < numResources; j++)
        {
            scanf("%d", &maximum[i][j]);
        }
    }
    // Resources allocated to processes
    printf("Enter allocated resources for each process:\n");
    for (int i = 0; i < numProcesses; i++)
    {
        printf("Process %d: ", i);
        for (int j = 0; j < numResources; j++)
        {
            scanf("%d", &allocation[i][j]);
        }
    }
    int choice;
    while (true)
    {
        displayMenu();
        scanf("%d", &choice);
        switch (choice)
        {
        case 1:
            calculateNeed();
            printf("Need Matrix:\n");
            for (int i = 0; i < numProcesses; i++)
            {
                for (int j = 0; j < numResources; j++)
                {
                    printf("%d ", need[i][j]);
                }
                printf("\n");
            }
            break;
        case 2:
        {
            int safeSequence[MAX_PROCESSES];
            if (isSafe(safeSequence))
            {
                printf("System is in a safe state.\n");
                printf("Safe Sequence: ");
                for (int i = 0; i < numProcesses; i++)
                {
                    printf("%d ", safeSequence[i]);
                }
                printf("\n");
            }
            else
            {
                printf("System is not in a safe state.\n");
            }
            break;
        }
        case 3:
        {
            int processID;
            int request[MAX_RESOURCES];
            printf("Enter process ID to request resources: ");
            scanf("%d", &processID);
            printf("Enter request for each resource type:\n");
            for (int j = 0; j < numResources; j++)
            {
                printf("Resource %d: ", j);
                scanf("%d", &request[j]);
            }
            requestResources(processID, request);
            break;
        }
        case 4:
            printf("Exiting...\n");
            return 0;
        default:
            printf("Invalid choice. Please try again.\n");
        }
    }
    return 0;
}