#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>
void *writer_thr(int temp);
void *reader_thr(int temp);
sem_t mutex;
sem_t db;
int readcount = 0, nwt, nrd;
int main()
{
    long int i;
    sem_init(&mutex, 0, 1); // Initialize mutex
    sem_init(&db, 0, 1);    // Initialize semaphore for database access
    pthread_t reader[100], writer[100];
    printf("\n Enter number of readers: ");
    scanf("%d", &nrd);
    printf("\n Enter number of writers: ");
    scanf("%d", &nwt);
    // Create writer threads
    for (i = 1; i <= nwt; i++)
    {
        pthread_create(&writer[i], NULL, (void *)writer_thr, (int *)i);
    }
    // Create reader threads
    for (i = 1; i <= nrd; i++)
    {
        pthread_create(&reader[i], NULL, (void *)reader_thr, (int *)i);
    }
    // Join writer threads
    for (i = 1; i <= nwt; i++)
    {
        pthread_join(writer[i], NULL);
    }
    // Join reader threads
    for (i = 1; i <= nrd; i++)
    {

        pthread_join(reader[i], NULL);
    }
    // Destroy semaphores
    sem_destroy(&db);
    sem_destroy(&mutex);
    return 0;
}
void *reader_thr(int temp)
{
    printf("\n Reader %d is trying to enter database for reading.", temp);
    sem_wait(&mutex); // Lock mutex for read count update
    readcount++;
    if (readcount == 1)
        sem_wait(&db); // If first reader, lock the database for reading
    sem_post(&mutex);  // Unlock mutex
    printf("\n Reader %d is now reading in database.", temp);
    sleep(3);         // Simulate reading time
    sem_wait(&mutex); // Lock mutex to update read count
    readcount--;
    if (readcount == 0)
        sem_post(&db); // If last reader, unlock the database
    sem_post(&mutex);  // Unlock mutex
    printf("\n Reader %d has left the database.\n", temp);
    return NULL;
}
void *writer_thr(int temp)
{
    printf("\n Writer %d is trying to enter database for modifying data", temp);
    sem_wait(&db); // Lock the database for writing
    printf("\n Writer %d is writing in database.", temp);
    sleep(3); // Simulate writing time
    printf("\n Writer %d is leaving the database.\n", temp);
    sem_post(&db); // Unlock the database
    return NULL;
}