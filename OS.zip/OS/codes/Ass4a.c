#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <semaphore.h>
#include <unistd.h>
#include <time.h>
#define BUFF_SIZE 5 // Buffer size
typedef struct
{
    int buf[BUFF_SIZE];
    int in;                // to produce
    int out;               // to consume
    sem_t full;            // Semaphore full
    sem_t empty;           // Semaphore empty
    pthread_mutex_t mutex; // Mutex
} sbuf_t;
sbuf_t shared;
// Producer thread function
void *Producer(void *arg)
{
    int index = *(int *)arg;
    while (1)
    {
        int R = rand() % 10;
        sem_wait(&shared.empty);
        pthread_mutex_lock(&shared.mutex);
        // Insert item into buffer
        shared.buf[shared.in] = R;
        printf("[P%d] Inserted %d\n", index, R);
        shared.in = (shared.in + 1) % BUFF_SIZE;
        // Display current buffer state
        printf("Buffer: ");
        for (int i = 0; i < BUFF_SIZE; i++)
        {
            printf("%d ", shared.buf[i]);
        }
        printf("\n");
        sleep(rand() % 7);
        pthread_mutex_unlock(&shared.mutex);
        sem_post(&shared.full);
    }

    return NULL;
}
// Consumer thread function
void *Consumer(void *arg)
{
    int index = *(int *)arg;
    while (1)
    {
        sem_wait(&shared.full);
        pthread_mutex_lock(&shared.mutex);
        // Remove item from buffer
        int item = shared.buf[shared.out];
        printf("[C%d] Consumed %d\n", index, item);
        shared.out = (shared.out + 1) % BUFF_SIZE;
        // Display current buffer state
        printf("Buffer: ");
        for (int i = 0; i < BUFF_SIZE; i++)
        {
            printf("%d ", shared.buf[i]);
        }
        printf("\n");
        sleep(rand() % 7);
        pthread_mutex_unlock(&shared.mutex);
        sem_post(&shared.empty);
    }
    return NULL;
}
int main()
{
    int NP, NC;
    pthread_t *idP, *idC;
    srand(time(NULL));
    // input
    printf("Enter number of producers: ");
    scanf("%d", &NP);
    printf("Enter number of consumers: ");
    scanf("%d", &NC);
    idP = malloc(NP * sizeof(pthread_t));
    idC = malloc(NC * sizeof(pthread_t));
    int *indicesP = malloc(NP * sizeof(int));
    int *indicesC = malloc(NC * sizeof(int));
    shared.in = 0;
    shared.out = 0;
    sem_init(&shared.full, 0, 0);
    sem_init(&shared.empty, 0, BUFF_SIZE);
    pthread_mutex_init(&shared.mutex, NULL);
    // Create producer threads
    for (int i = 0; i < NP; i++)
    {
        indicesP[i] = i; // Store index for each producer
        pthread_create(&idP[i], NULL, Producer, (void *)&indicesP[i]);
    }
    // Create consumer threads
    for (int i = 0; i < NC; i++)
    {
        indicesC[i] = i; // Store index for each consumer
        pthread_create(&idC[i], NULL, Consumer, (void *)&indicesC[i]);
    }
    // Wait for all producer threads to finish
    for (int i = 0; i < NP; i++)
    {
        pthread_join(idP[i], NULL);
    }
    // Wait for all consumer threads to finish
    for (int i = 0; i < NC; i++)
    {
        pthread_join(idC[i], NULL);
    }
    return 0;
}