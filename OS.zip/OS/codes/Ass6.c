#include <stdio.h>
// Function to print the current state of frames and highlight page fault
void printFrames(int temp[], int frames, int page, int pageFault)
{
    printf("Page %d: ", page);
    for (int j = 0; j < frames; j++)
    {
        if (temp[j] != -1)
            printf("%d\t", temp[j]);
        else
            printf("-\t");
    }
    if (pageFault)
        printf(" <- Page Fault");
    else
        printf(" <- ----------");
    printf("\n");
}
// FIFO Algorithm
void fifo(int pageString[], int n, int frames)
{
    int temp[10], k = 0, faults = 0, flag;
    for (int i = 0; i < frames; i++)
    {
        temp[i] = -1;
    }
    printf("\nFIFO Page Replacement\n");
    for (int i = 0; i < n; i++)
    {
        flag = 0;
        for (int j = 0; j < frames; j++)
        {
            if (temp[j] == pageString[i])
            {
                flag = 1;
                break;
            }
        }
        if (flag == 0)
        {
            temp[k] = pageString[i];
            k = (k + 1) % frames;
            faults++;
        }

        printFrames(temp, frames, pageString[i], flag == 0);
    }
    printf("\nTotal Page Faults: %d\n", faults);
}
// Function to find the farthest page for Optimal Replacement
int findFarthest(int pageString[], int temp[], int frames, int n, int currentPos)
{
    int farthestIndex = -1, farthestDistance = -1;
    for (int i = 0; i < frames; i++)
    {
        int found = 0;
        for (int j = currentPos + 1; j < n; j++)
        {
            if (temp[i] == pageString[j])
            {
                if (j > farthestDistance)
                {
                    farthestDistance = j;
                    farthestIndex = i;
                }
                found = 1;
                break;
            }
        }
        if (!found)
        {
            return i;
        }
    }
    return (farthestIndex == -1) ? 0 : farthestIndex;
}
// Optimal Algorithm
void optimal(int pageString[], int n, int frames)
{
    int temp[10], faults = 0, flag;
    for (int i = 0; i < frames; i++)
    {
        temp[i] = -1;
    }
    printf("\nOptimal Page Replacement\n");
    for (int i = 0; i < n; i++)
    {

        flag = 0;
        for (int j = 0; j < frames; j++)
        {
            if (temp[j] == pageString[i])
            {
                flag = 1;
                break;
            }
        }
        if (flag == 0)
        {
            if (i < frames)
            {
                temp[i] = pageString[i];
            }
            else
            {
                int replaceIndex = findFarthest(pageString, temp, frames, n, i);
                temp[replaceIndex] = pageString[i];
            }
            faults++;
        }
        printFrames(temp, frames, pageString[i], flag == 0);
    }
    printf("\nTotal Page Faults: %d\n", faults);
}
// Function to find the least recently used page for LRU
int findLRU(int time[], int frames)
{
    int minTime = time[0], pos = 0;
    for (int i = 1; i < frames; i++)
    {
        if (time[i] < minTime)
        {
            minTime = time[i];
            pos = i;
        }
    }
    return pos;
}
// LRU Algorithm
void lru(int pageString[], int n, int frames)
{
    int temp[10], time[10], faults = 0, flag, counter = 0;
    for (int i = 0; i < frames; i++)
    {
        temp[i] = -1;

        time[i] = -1;
    }
    printf("\nLRU Page Replacement\n");
    for (int i = 0; i < n; i++)
    {
        flag = 0;
        for (int j = 0; j < frames; j++)
        {
            if (temp[j] == pageString[i])
            {
                flag = 1;
                counter++;
                time[j] = counter;
                break;
            }
        }
        if (flag == 0)
        {
            if (i < frames)
            {
                temp[i] = pageString[i];
                counter++;
                time[i] = counter;
            }
            else
            {
                int lruIndex = findLRU(time, frames);
                temp[lruIndex] = pageString[i];
                counter++;
                time[lruIndex] = counter;
            }
            faults++;
        }
        printFrames(temp, frames, pageString[i], flag == 0);
    }
    printf("\nTotal Page Faults: %d\n", faults);
}
int main()
{
    int choice, frames, n, pageString[30];
    printf("Enter the number of frames: ");
    scanf("%d", &frames);

    printf("Enter the length of the page string: ");
    scanf("%d", &n);
    printf("Enter the page string: ");
    for (int i = 0; i < n; i++)
    {
        scanf("%d", &pageString[i]);
    }
    do
    {
        printf("\nChoose a Page Replacement Algorithm:\n");
        printf("1. FIFO\n");
        printf("2. Optimal\n");
        printf("3. LRU\n");
        printf("4. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);
        switch (choice)
        {
        case 1:
            fifo(pageString, n, frames);
            break;
        case 2:
            optimal(pageString, n, frames);
            break;
        case 3:
            lru(pageString, n, frames);
            break;
        case 4:
            printf("Exiting...\n");
            break;
        default:
            printf("Invalid choice! Please try again.\n");
        }
    }
        while (choice != 4);
    return 0;
}