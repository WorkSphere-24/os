#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

// Function to swap two rows in a 2D array
void swapRows(int arr[][5], int row1, int row2, int m) {
    int temp;
    for (int i = 0; i < m; i++) {
        temp = arr[row1][i];
        arr[row1][i] = arr[row2][i];
        arr[row2][i] = temp;
    }
}

// Sorting processes based on arrival time (AT)
void sort(int arr[][5], int n, int m) {
    for (int i = 0; i < n - 1; i++)
        for (int j = 0; j < n - i - 1; j++)
            if (arr[j][1] > arr[j + 1][1])
                swapRows(arr, j, j + 1, m);
}

// Function to print Output Table
void printTable(int arr[][5], int n, int completionTime[], int turnaroundTime[], int waitingTime[]) {
    printf("P\tAT\tBT\tCT\tTAT\tWT\n");
    for (int i = 0; i < n; i++) 
        printf("%d\t%d\t%d\t%d\t%d\t%d\n", arr[i][0], arr[i][1], arr[i][2], completionTime[i], turnaroundTime[i], waitingTime[i]);
    
    float sumWT = 0;
    for (int i = 0; i < n; i++)
        sumWT += waitingTime[i];
    
    float avgWT = sumWT / n;
    printf("Average Waiting Time: %.2f\n", avgWT);
}

// Function to print the Gantt chart
void printGanttChart(int ganttProcess[], int ganttTime[], int ganttIndex, int currentTime) {
    printf("\nGantt Chart\n");
    for (int i = 0; i < ganttIndex; i++) 
        if (i == 0 || ganttProcess[i] != ganttProcess[i - 1]) 
            printf("| P%d ", ganttProcess[i]);  // Print process ID
    
    printf("|\n");

    for (int i = 0; i < ganttIndex; i++) 
        if (i == 0 || ganttProcess[i] != ganttProcess[i - 1]) 
            printf("%d ", ganttTime[i]);  // Print start time of process

    printf("%d\n", currentTime);  // Print the final time
}

// Function to implement SJF non-preemptive scheduling
void sjfNonPreemptive(int arr[][5], int n) {
    sort(arr, n, 5);
    int completionTime[n], turnaroundTime[n], waitingTime[n];
    int currentTime = 0, completed = 0;
    
    while (completed != n) {
        int minIndex = -1;
        int minBurstTime = INT_MAX;

        for (int i = 0; i < n; i++) {
            if (arr[i][1] <= currentTime && arr[i][2] < minBurstTime && completionTime[i] == 0) {
                minBurstTime = arr[i][2];
                minIndex = i;
            }
        }

        if (minIndex == -1) {
            currentTime++;
            continue;
        }

        currentTime += arr[minIndex][2];
        completionTime[minIndex] = currentTime;
        turnaroundTime[minIndex] = completionTime[minIndex] - arr[minIndex][1];
        waitingTime[minIndex] = turnaroundTime[minIndex] - arr[minIndex][2];
        completed++;
    }

    printTable(arr, n, completionTime, turnaroundTime, waitingTime);
}

// Function to implement SJF preemptive scheduling (SRTF)
void srtf(int arr[][5], int n) {
    sort(arr, n, 5);
    int completionTime[n], turnaroundTime[n], waitingTime[n];
    int remainingTime[n];
    int currentTime = 0, completed = 0, minIndex;
    int ganttProcess[100], ganttTime[100], ganttIndex = 0;


    for (int i = 0; i < n; i++)
        remainingTime[i] = arr[i][2];
    
    while (completed != n) {
        minIndex = -1;
        int minRemainingTime = INT_MAX;
        
        for (int i = 0; i < n; i++) {
            if (arr[i][1] <= currentTime && remainingTime[i] > 0 && remainingTime[i] < minRemainingTime) {
                minRemainingTime = remainingTime[i];
                minIndex = i;
            }
        }

        if (minIndex == -1) {
            currentTime++;
            continue;
        }

        ganttProcess[ganttIndex] = arr[minIndex][0];
        ganttTime[ganttIndex] = currentTime;
        ganttIndex++;

        remainingTime[minIndex]--;
        currentTime++;

        if (remainingTime[minIndex] == 0) {
            completed++;
            completionTime[minIndex] = currentTime;
            turnaroundTime[minIndex] = completionTime[minIndex] - arr[minIndex][1];
            waitingTime[minIndex] = turnaroundTime[minIndex] - arr[minIndex][2];
        }
    }

    printTable(arr, n, completionTime, turnaroundTime, waitingTime);
    printGanttChart(ganttProcess, ganttTime, ganttIndex, currentTime);
}

// Function to implement Round Robin scheduling
void roundRobin(int arr[][5], int n, int quantum) {
    int remainingTime[n], waitingTime[n], turnaroundTime[n], completionTime[n];
    int currentTime = 0, completed = 0, ganttProcess[100], ganttTime[100], ganttIndex = 0;
    int queue[100], front = 0, rear = 0, inQueue[n];

    for (int i = 0; i < n; i++) {
        remainingTime[i] = arr[i][2];
        inQueue[i] = 0;
        completionTime[i] = 0;
    }

    sort(arr, n, 5);
    queue[rear++] = 0;
    inQueue[0] = 1;

    while (completed != n) {
        int idle = 1;

        while (front != rear) {
            int i = queue[front++];
            idle = 0;

            ganttProcess[ganttIndex] = arr[i][0];
            ganttTime[ganttIndex] = currentTime;
            ganttIndex++;

            if (remainingTime[i] > quantum) {
                currentTime += quantum;
                remainingTime[i] -= quantum;
            } else {
                currentTime += remainingTime[i];
                completionTime[i] = currentTime;
                remainingTime[i] = 0;
                completed++;
                turnaroundTime[i] = completionTime[i] - arr[i][1];
                waitingTime[i] = turnaroundTime[i] - arr[i][2];
            }

            for (int j = 0; j < n; j++)
                if (arr[j][1] <= currentTime && remainingTime[j] > 0 && !inQueue[j]) {
                    queue[rear++] = j;
                    inQueue[j] = 1;
                }

            if (remainingTime[i] > 0)
                queue[rear++] = i;
        }

        if (idle) {
            currentTime++;
            for (int j = 0; j < n; j++)
                if (arr[j][1] <= currentTime && remainingTime[j] > 0 && !inQueue[j]) {
                    queue[rear++] = j;
                    inQueue[j] = 1;
                }
        }
    }

    printTable(arr, n, completionTime, turnaroundTime, waitingTime);
    printGanttChart(ganttProcess, ganttTime, ganttIndex, currentTime);
}

int main() {
    int n, choice, quantum;

    printf("Enter number of processes: ");
    scanf("%d", &n);
    if (n <= 0) {
        printf("Number of processes must be positive.\n");
        return 1;
    }

    int arr[n][5];

    for (int i = 0; i < n; i++) {
        arr[i][0] = i + 1;
        printf("Enter arrival time for process %d: ", i + 1);
        scanf("%d", &arr[i][1]);
        printf("Enter burst time for process %d: ", i + 1);
        scanf("%d", &arr[i][2]);
    }

    printf("Choose Scheduling Algorithm:\n");
    printf("1. Shortest Job First (Non-Preemptive)\n");
    printf("2. Shortest Job First (Preemptive, SRTF)\n");
    printf("3. Round Robin\n");
    printf("Enter your choice: ");
    scanf("%d", &choice);

    switch (choice) {
        case 1:
            sjfNonPreemptive(arr, n);
            break;
        case 2:
            srtf(arr, n);
            break;
        case 3:
            printf("Enter time quantum for Round Robin: ");
            scanf("%d", &quantum);
            roundRobin(arr, n, quantum);
            break;
        default:
            printf("Invalid choice!\n");
    }
    return 0;
}
