#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
   printf("Child process displaying array in reverse order:\n");
   for (int i = argc - 1; i > 0; i--) {
       printf("%s ", argv[i]); // Print each argument in reverse order
   }
   printf("\n");
   return 0;
}
