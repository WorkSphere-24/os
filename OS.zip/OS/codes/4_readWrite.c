#include<stdio.h>
#include<stdlib.h>
#include<time.h>
#include<pthread.h>
#include<semaphore.h>
#include<sys/wait.h>

#define WRITERS 2
#define READERS 3

sem_t wsem;
pthread_mutex_t mutex;
int data = 0;
int read_count = 0;

void *writer(void *arg)
{
    long id = (long)arg;
    while(1)
    {
        sem_wait(&wsem);

        printf("Writer %ld Entering Critical Section\n", id);
        data = rand()%100;
        printf("Writer %ld wrote Data: %d", id, data);
        printf("Writer %ld Exiting Critical Section\n, id");
        
        sem_post(&wsem);
        sleep(2);
    }
    return NULL;
}

void *reader(void *arg)
{
    long id = (long)arg;
    while(1)
    {
        pthread_mutex_lock(&mutex);
        read_count++;
        if(read_count == 1)
        {
            sem_wait(&wsem);
        }
        pthread_mutex_unlock(&mutex);
        printf("Reader %ld Entering Critical Section", id);

        printf("Reader %ld read Data: %d", id, data);

        pthread_mutex_lock(&mutex);
        read_count--;
        if(read_count == 0)
        {
            sem_post(&wsem);
        }
        pthread_mutex_unlock(&mutex);
        printf("Reader %ld Exiting Critical Section", id);
        sleep(1);
    }
    return NULL;
}

int main()
{
    pthread_t readers[READERS], writers[WRITERS];
    sem_init(&wsem, 0, 1);
    pthread_mutex_init(&mutex, NULL);
    for(int i = 0; i < WRITERS; i++)
    {
        pthread_create(&writers[i], NULL, writer, (void*)(uintptr_t)i);
    }
    for(int i = 0; i < READERS; i++)
    {
        pthread_create(&readers[i], NULL, reader, (void*)i);
    }
    for(int i = 0; i < WRITERS; i++)
    {
        pthread_join(&writers[i], NULL);
    }
    for(int i = 0; i < READERS; i++)
    {
        pthread_join(&readers[i], NULL);
    }
    sem_destroy(&wsem);
    pthread_mutex_destroy(&mutex);

    return 0;
}
