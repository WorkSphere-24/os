#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <string.h>

void selectionSort(int arr[], int n)
{
    for (int i = 0; i < n - 1; i++)
    {
        int idx = i;
        for (int j = i + 1; j < n; j++)
            if (arr[j] < arr[idx])
                idx = j;

        int temp = arr[idx];
        arr[idx] = arr[i];
        arr[i] = temp;
    }
}

int main()
{
    int n;
    
    // Get the number of elements from the user
    printf("Enter the number of elements: ");
    scanf("%d", &n);
    
    // Allocate memory for the array
    int arr[n];

    // Get the elements from the user
    printf("Enter %d elements:\n", n);
    for (int i = 0; i < n; i++)
        scanf("%d", &arr[i]);

    pid_t pid = fork();

    if (pid < 0)
    {
        fprintf(stderr, "Fork failed\n");
        return 1;
    }
    else if (pid == 0)
    {
        // Child process
        // Convert the array to string arguments for execve
        char *args[n + 1];
        for (int i = 0; i < n; i++)
        {
            args[i] = malloc(12);           // Allocate space for each integer
            sprintf(args[i], "%d", arr[i]); // Convert integer to string
        }
        args[n] = NULL; // Last argument must be NULL

        // Load new program to display the array in reverse order
        // mention name properly
        if (execve("./Ass2_child", args, NULL) == -1)
        {
            perror("execve failed");
            exit(1);
        }
    }
    else
    {
        // Parent process
        selectionSort(arr, n); // Sort array
        printf("\nParent process sorted array in ascending order: ");
        for (int i = 0; i < n; i++)
            printf("%d ", arr[i]);
        printf("\n");
    
        // Wait for child process to finish
        wait(NULL);
        printf("Parent process exiting.\n");
        return 0;
    }
}
